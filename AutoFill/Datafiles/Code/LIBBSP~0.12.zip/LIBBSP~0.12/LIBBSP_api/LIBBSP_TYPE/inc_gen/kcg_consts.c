/* $********** SCADE Suite KCG 32-bit 6.6 (build i19) ***********
** Command: kcg66.exe -config ..\..\LIBBSP_api\LIBBSP_TYPE\config.txt
** Generation date: 2023-02-08T15:08:48
*************************************************************$ */

#include "kcg_consts.h"

/* C_LIBBSP_PSUM_INIT_COUPLE/ */
const TS_LIBBSP_PSUM_Conf C_LIBBSP_PSUM_INIT_COUPLE = { kcg_lit_uint32(0),
  kcg_lit_uint32(0) };

/* $********** SCADE Suite KCG 32-bit 6.6 (build i19) ***********
** kcg_consts.c
** Generation date: 2023-02-08T15:08:48
*************************************************************$ */


/* $********** SCADE Suite KCG 32-bit 6.6 (build i19) ***********
** Command: kcg66.exe -config ..\..\LIBBSP_api\LIBBSP_TYPE\config.txt
** Generation date: 2023-02-08T15:08:48
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "DummyForGeneration.h"

/* DummyForGeneration/ */
void DummyForGeneration(void)
{
}






/* $********** SCADE Suite KCG 32-bit 6.6 (build i19) ***********
** DummyForGeneration.c
** Generation date: 2023-02-08T15:08:48
*************************************************************$ */


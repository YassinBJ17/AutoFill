/* $********** SCADE Suite KCG 32-bit 6.6 (build i19) ***********
** Command: kcg66.exe -config ..\..\LIBBSP_api\LIBBSP_TYPE\config.txt
** Generation date: 2023-02-08T15:08:48
*************************************************************$ */
#ifndef _DummyForGeneration_H_
#define _DummyForGeneration_H_

#include "kcg_types.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* ======================  no context type  ======================== */

/* ===========  node initialization and cycle functions  =========== */
/* DummyForGeneration/ */
extern void DummyForGeneration(void);



#endif /* _DummyForGeneration_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6 (build i19) ***********
** DummyForGeneration.h
** Generation date: 2023-02-08T15:08:48
*************************************************************$ */


/* $********** SCADE Suite KCG 32-bit 6.6 (build i19) ***********
** Command: kcg66.exe -config ..\..\LIBBSP_api\LIBBSP_TYPE\config.txt
** Generation date: 2023-02-08T15:08:48
*************************************************************$ */
#ifndef _KCG_SENSORS_H_
#define _KCG_SENSORS_H_

#include "kcg_types.h"

#endif /* _KCG_SENSORS_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6 (build i19) ***********
** kcg_sensors.h
** Generation date: 2023-02-08T15:08:48
*************************************************************$ */


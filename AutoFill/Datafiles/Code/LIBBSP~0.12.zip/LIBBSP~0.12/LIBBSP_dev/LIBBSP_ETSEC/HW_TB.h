#ifndef HW_TB_H
#define HW_TB_H

#include "LIBMCP_Types.h"
#include "HW_TBL.h"

void HW_TB_wait (const uint32_t number_of_us);

#endif

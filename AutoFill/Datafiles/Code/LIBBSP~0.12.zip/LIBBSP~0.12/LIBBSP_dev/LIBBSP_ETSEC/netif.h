#ifndef NETIF_H
#define NETIF_H

#include "LIBMCP_Types.h"
#include "MAC_interface.h"
//#include "ethernet.h"
#include "HW_CONF.h"

#include "LIBBSP_ETSEC.h"

#endif

#ifndef HW_TBL_H
#define HW_TBL_H

#include "LIBMCP_Types.h"

uint32_t tbl (void);

#endif

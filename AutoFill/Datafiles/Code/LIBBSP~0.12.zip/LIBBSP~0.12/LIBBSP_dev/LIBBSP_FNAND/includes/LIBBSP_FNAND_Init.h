/****************************************************************************************/
/*                                                                                      */
/*--------------------------------------------------------------------------------------*/
/* Copyright (c) 2021                                                                  */
/* SAFRAN Electronics & Defense. Reproduction and disclosure forbidden.                 */
/****************************************************************************************/
#ifndef LIBBSP_FNAND_INIT_H
#define LIBBSP_FNAND_INIT_H

//#include "LIBBSP_CMN.h"
#include "LIBBSP_FNAND_Globals.h"
#include "LIBBSP_FNAND_InitCard.h"
#include "LIBBSP_FNAND_InitHost.h"

/*==== Definitions =====================================================================*/

/*==== Variables =======================================================================*/

/*==== Services ========================================================================*/
//void LIBBSP_FNAND_Init(void);

/*==== END =============================================================================*/
#endif /* LIBBSP_FNAND_INIT_H */
